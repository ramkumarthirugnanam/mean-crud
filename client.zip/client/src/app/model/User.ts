export class User {
   name: string;
   phoneNumber: number;
  address: string;
  state : string;
  city : string;
}
